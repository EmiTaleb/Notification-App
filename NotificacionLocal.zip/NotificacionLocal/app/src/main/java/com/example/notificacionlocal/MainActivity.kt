package com.example.notificacionlocal

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private val channel_id = "1000"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val boton = findViewById<Button>(R.id.btnNotificaiones)
        boton.setOnClickListener(){
            createNot()
            enviarNot()
        }

    }
    private fun createNot()
    {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val name = "Canal 1000"
            val descri = "Canal de Notificaciones"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(channel_id,name,importance).apply {
                description = descri
            }
            val notificationManager : NotificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun enviarNot()
    {
        val mensaje = "Recuerda que en nuestra Tienda Online, Todos los jueves hay 3x2 en productos participantes, Solo en pago de Contado y a Meses sin Intereses con tarjetas participantes"
        if (ContextCompat.checkSelfPermission(this,android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),1)
        }
        else{
            val intent = Intent(this,MainActivity2::class.java).apply {
                putExtra("notification_message",mensaje)
            }
            val pendingIntent : PendingIntent = PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)



            val builder = NotificationCompat.Builder(this,channel_id)
                .setSmallIcon(R.drawable.ic_reloj)
                .setContentTitle("Super Jueves")
                .setContentText(mensaje)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
            Log.d("MainActivity", "Notificación enviada")
            with(NotificationManagerCompat.from(this)){
                notify(1,builder.build())
        }

        }
    }
}